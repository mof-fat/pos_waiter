Odoo PoS Waiter
Odoo Version 10
Category: "Point Of Sale"
======================================================================
### FEATURES
1. Define an employee as a waiter at the point of sale;
2. Waiter selection screen for POS order;
3. Waiter name on POS ticket;
4. Identify the waiter of each point of sale order;
5. Create a waiter in point of sale module;

### INSTALLATION
1.Download the module from odoo apps store;
2.Put the module in your defined addons folder;
3.Restart odoo server;
4.Activate developer mode;
5.Update odoo apps list;
6.Search the module "grc_pos_waiter"
7.Install the module
=================================================
You're done !

### SUPPORT AND BUGS
<graciaskas96@gmail.com>